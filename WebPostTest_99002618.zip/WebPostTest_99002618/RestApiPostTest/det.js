function submit(){
    uname=document.getElementById("username").value
    city=document.getElementById("city").value
    emaill=document.getElementById("eMail").value
    phonee=document.getElementById("ph").value
    document.getElementById("mydiv").innerHTML=uname+" "+city
     
     }