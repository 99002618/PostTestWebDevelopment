function selectDevice(){
    item1 = 'Lenovo+Sony+Hp+Dell';
    lap = item1.split('+').join(" <br> ");
    
    item2 = 'iPhone+Samsung+Sony+Oppo';
    mob = item2.split('+').join(" <br> ");

    item3 = 'Samsung+Sony+Lenovo+LG';
    tele = item3.split('+').join(" <br> ");

    var selection = document.getElementById("myDevice");
    
    if(selection.value == 'LAPTOP'){
        document.getElementById("myde").innerHTML=lap;
    }
    else if(selection.value == 'MOBILE'){
        document.getElementById("myde").innerHTML=mob;
    }
    else if(selection.value == 'TV'){
        document.getElementById("myde").innerHTML=tele;
    }
    else{
        document.getElementById("myde").innerHTML="";
    }
}