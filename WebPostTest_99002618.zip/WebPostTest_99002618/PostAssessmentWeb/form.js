function validation(){
    if(document.getElementById("uname").value==""){
        alert("Enter your NAME");
        document.registrationform.username.focus();
     }

    else if(document.getElementById("email").value==""){
        alert("Enter your Email");
        document.registrationform.uage.focus();
     }

    else if(document.getElementById("pass").value==""){
        alert("Enter PASSWORD");
        document.registrationform.password.focus();
     }
     else if(document.getElementById("phone").value==""){
        alert("Enter phone no.");
        document.registrationform.password.focus();
     }
    
    else{
        validateuser();
     }
     }
    function validateuser(){
        var usern=["Ankitha","Siri","Pari","Harini"];
        var flag=0;
        var uName=document.getElementById("uname").value;

    for(let i=0;i<usern.length;i++){
        if(uName==usern[i])
        {
            flag=1;
            break;
        }
        }
        if(flag==1){
            alert("This username already exists");
        }
        else{
            document.registrationform.submit();
        }
     }